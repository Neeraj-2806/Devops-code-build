sudo apt-get update
sudo apt install nginx -y
