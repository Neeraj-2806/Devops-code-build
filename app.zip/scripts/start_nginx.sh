sudo service nginx start
